﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using MayvueTechTest.Models;

namespace MayvueTechTest.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MotionPictureController : ControllerBase
    {
        private readonly IConfiguration _configuration;
        public MotionPictureController(IConfiguration configuration)
        {
            _configuration = configuration;
        }


        // Get Movies
        [HttpGet]
        public JsonResult Get()
        {
            string query = @"SELECT * FROM dbo.MotionPictures";

            DataTable table = new DataTable();
            string sqlDataSource = _configuration.GetConnectionString("MotionPictureCon");
            SqlDataReader myReader;
            using (SqlConnection myCon = new SqlConnection(sqlDataSource))
            {
                myCon.Open();
                using(SqlCommand myCommand = new SqlCommand(query, myCon))
                {
                    myReader = myCommand.ExecuteReader();
                    table.Load(myReader);
                    myReader.Close();
                    myCon.Close();

                }
            }

            return new JsonResult(table);
        }

        // Post Movie
        [HttpPost]
        public JsonResult Post(MotionPictures MP)
        {
            string query = @"INSERT INTO dbo.MotionPictures (Name, Description, ReleaseYear) VALUES (@Name, @Description, @ReleaseYear)";

            DataTable table = new DataTable();
            string sqlDataSource = _configuration.GetConnectionString("MotionPictureCon");
            SqlDataReader myReader;
            using (SqlConnection myCon = new SqlConnection(sqlDataSource))
            {
                myCon.Open();
                using (SqlCommand myCommand = new SqlCommand(query, myCon))
                {
                    myCommand.Parameters.AddWithValue("@Name", MP.Name);
                    myCommand.Parameters.AddWithValue("@Description", MP.Description);
                    myCommand.Parameters.AddWithValue("@ReleaseYear", MP.ReleaseYear);
                    myReader = myCommand.ExecuteReader();
                    table.Load(myReader);
                    myReader.Close();
                    myCon.Close();

                }
            }

            return new JsonResult("Successfully Added");
        }

        // Update Movie
        [HttpPut]
        public JsonResult Put(MotionPictures MP)
        {
            string query = @"UPDATE dbo.MotionPictures SET Name = @Name, Description = @Description, ReleaseYear = @ReleaseYear WHERE ID = @ID";

            DataTable table = new DataTable();
            string sqlDataSource = _configuration.GetConnectionString("MotionPictureCon");
            SqlDataReader myReader;
            using (SqlConnection myCon = new SqlConnection(sqlDataSource))
            {
                myCon.Open();
                using (SqlCommand myCommand = new SqlCommand(query, myCon))
                {
                    myCommand.Parameters.AddWithValue("@ID", MP.ID);
                    myCommand.Parameters.AddWithValue("@Name", MP.Name);
                    myCommand.Parameters.AddWithValue("@Description", MP.Description);
                    myCommand.Parameters.AddWithValue("@ReleaseYear", MP.ReleaseYear);
                    myReader = myCommand.ExecuteReader();
                    table.Load(myReader);
                    myReader.Close();
                    myCon.Close();

                }
            }

            return new JsonResult("Successfully Updated");
        }
        
        // Delete Movie
        [HttpDelete("{id}")]
        public JsonResult Delete(int id)
        {
            string query = @"DELETE FROM dbo.MotionPictures WHERE ID = @ID";

            DataTable table = new DataTable();
            string sqlDataSource = _configuration.GetConnectionString("MotionPictureCon");
            SqlDataReader myReader;
            using (SqlConnection myCon = new SqlConnection(sqlDataSource))
            {
                myCon.Open();
                using (SqlCommand myCommand = new SqlCommand(query, myCon))
                {
                    myCommand.Parameters.AddWithValue("@ID", id);
                    myReader = myCommand.ExecuteReader();
                    table.Load(myReader);
                    myReader.Close();
                    myCon.Close();

                }
            }

            return new JsonResult("Successfully Deleted");
        }
    }
}
